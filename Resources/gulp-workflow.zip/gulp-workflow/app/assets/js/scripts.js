(function ($, window, document, undefined) {

  'use strict';

  $(function () {
    // your scripts
  });

})(jQuery, window, document);
